// Informações do gráfico 1


var data;

  if(localStorage.getItem('data')==null){
    data = {
      labels: ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'],
      datasets: [{
        label: 'Horas Dormidas',
        data: [6, 5, 5.5, 6, 7, 8, 9],
        backgroundColor: [
          'rgba(255, 26, 104, 0.2)',
          'rgba(255, 26, 104, 0.2)',
          'rgba(255, 26, 104, 0.2)',
          'rgba(255, 26, 104, 0.2)',
          'rgba(255, 26, 104, 0.2)',
          'rgba(255, 26, 104, 0.2)',
          'rgba(255, 26, 104, 0.2)',
        ],
        borderColor: [
          'rgba(255, 26, 104, 1)',
          'rgba(255, 26, 104, 1)',
          'rgba(255, 26, 104, 1)',
          'rgba(255, 26, 104, 1)',
          'rgba(255, 26, 104, 1)',
          'rgba(255, 26, 104, 1)',
          'rgba(255, 26, 104, 1)',
        ],
        borderWidth: 2
      }]
    };
    localStorage.setItem('data',JSON.stringify(data));
  }
  else{
    data = JSON.parse(localStorage.getItem('data'));
  }

  // Tipo do gráfico(barra)
  const config = {
    type: 'bar',
    data,
    options: {
      responsive: true,
        aspectRatio: false,
      scales: {
        y: {
          beginAtZero: true
        }
      }
    }
  };

  // Gerar gráfico
  const myChart = new Chart(
    document.getElementById('myChart'),
    config
  );

  // Gráfico de linha
  // Informações do gráfico 2
  
document.getElementById('formSono').addEventListener('submit',(evento)=>{
  let dormiu = +document.getElementById('dormiu').value;
  let acordou = +document.getElementById('acordou').value;
  let diasSemana = document.querySelectorAll('#diasDaSemana input');
  let diaSelect = 0;
  for(let i = 0; i < diasSemana.length;i++){
    if(diasSemana[i].checked == true){
      diaSelect = i;
      i = diasSemana.length;
    }
  }
  let horasDormidas = (acordou - dormiu >= 0) ? acordou - dormiu : (acordou - dormiu) + 24;
  //alert(`dia: ${diaSelect} horas: ${horasDormidas}`);
  data.datasets[0].data[diaSelect]=horasDormidas;
  localStorage.setItem('data',JSON.stringify(data));
  window.location.reload();
  evento.preventDefault();
});