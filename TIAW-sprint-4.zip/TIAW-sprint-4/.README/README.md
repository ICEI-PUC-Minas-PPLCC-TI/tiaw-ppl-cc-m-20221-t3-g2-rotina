# Routinizer - Sprint 4 TIAW

Sprint 4 de TIAW feito pelos alunos da PUC-Minas - Ciência da Computação.

Disciplina - Trabalho Interdisciplinar: Aplicações Web, PUC-Minas Belo Horizonte, primeiro período de Ciência da Computação.

  - Links Úteis: 
  - link repositorio github: https://github.com/ICEI-PUC-Minas-PPLCC-TI/tiaw-ppl-cc-m-20221-t3-g2-rotina
  - link hospedagem Replit: https://TIAW-sprint-4.fabrizioperagal.repl.co


# Estrutura de Diretórios

Componentes do Grupo:

  - Arthur Justino Dias
  - Fabrizio Peragallo de Mello
  - Gabriel Azevedo Fernandes
  - Gabriel Pinto Azevedo
  - Giovanna de Àvila Pedersoli Rocha
  - Pedro Henrique Moreira


Este diretório armazena os códigos fontes dos sprints feitos e utilizam as tecnologias HTML, CSS e
JavaScript.


