  $(function(){

	var operacao = "A"; //"A"=Adição; "E"=Edição

	var indice_selecionado = -1;

	var tbDesafios = localStorage.getItem("tbDesafios");// Recupera os dados armazenados

	tbDesafios = JSON.parse(tbDesafios); // Converte string para objeto

	if(tbDesafios == null) // Caso não haja conteúdo, iniciamos um vetor vazio
		tbDesafios = [];

	function Adicionar(){
		var cli = GetCliente("Desafio", $("#txtDesafio").val());

		if(cli != null){
			alert("Desafio já cadastrado.");
			return;
		}

		var desafios = JSON.stringify({
			Desafio: $("#txtDesafio").val(),
			Detalhamento: $("#txtDetalhe").val(),
			Data: $("#txtData").val(),
			Comentarios: $("#txtComentario").val()
		});

		tbDesafios.push(desafios);   

		localStorage.setItem("tbDesafios", JSON.stringify(tbDesafios));

		alert("Registro adicionado.");
		return true;
	}

	function Editar(){
		tbDesafios[indice_selecionado] = JSON.stringify({
            Desafio: $("#txtDesafio").val(),
			Detalhamento: $("#txtDetalhe").val(),
			Data: $("#txtData").val(),
			Comentarios: $("#txtComentario").val()
			});
		localStorage.setItem("tbDesafios", JSON.stringify(tbDesafios));
		alert("Informações editadas.")
		operacao = "A";
		return true;
	}

	function Listar(){
		$("#tblListar").html("");
		$("#tblListar").html(
			"<thead>"+
			"	<tr>"+
			"<th></th>"+
			"	<th>Desafio</th>"+
			"	<th>Detalhamento</th>"+
			"	<th>Data</th>"+
			"	<th>Comentários</th>"+
			"	</tr>"+
			"</thead>"+
			"<tbody>"+
			"</tbody>"
			);

		 for(var i in tbDesafios){
			var cli = JSON.parse(tbDesafios[i]);
		  	$("#tblListar tbody").append("<tr>"+
									 	 "	<td><img src='edit.png' alt='"+i+"' class='btnEditar'/><img src='delete.png' alt='"+i+"' class='btnExcluir'/><img src='done.png' alt='"+i+"' class='btnDone'/></td>" + 
										 "	<td>"+cli.Desafio+"</td>" + 
										 "	<td>"+cli.Detalhamento+"</td>" + 
										 "	<td>"+cli.Data+"</td>" + 
										 "	<td>"+cli.Comentarios+"</td>" + 
		  								 "</tr>");
		 }
	}

	function Excluir(){
		tbDesafios.splice(indice_selecionado, 1);
		localStorage.setItem("tbDesafios", JSON.stringify(tbDesafios));
		alert("Desafio Excluído.");
	}

	function Concluido(){
		tbDesafios.splice(indice_selecionado, 1);
		localStorage.setItem("tbDesafios", JSON.stringify(tbDesafios));
		alert("Desafio Concluído!");
	}

	function GetCliente(propriedade, valor){
		var cli = null;
        for (var item in tbDesafios) {
            var i = JSON.parse(tbDesafios[item]);
            if (i[propriedade] == valor)
                cli = i;
        }
        return cli;
	}

	Listar();

	$("#frmCadastro").on("submit",function(){
		if(operacao == "A")
			return Adicionar();
		else
			return Editar();		
	});

	$("#tblListar").on("click", ".btnEditar", function(){
		operacao = "E";
		indice_selecionado = parseInt($(this).attr("alt"));
		var cli = JSON.parse(tbDesafios[indice_selecionado]);
		$("#txtDesafio").val(cli.Desafio);
		$("#txtDetalhe").val(cli.Detalhamento);
		$("#txtData").val(cli.Data);
		$("#txtComentario").val(cli.Comentarios);
		$("#txtDetalhamento").focus();
	});

	$("#tblListar").on("click", ".btnExcluir", function(){
		indice_selecionado = parseInt($(this).attr("alt"));
		Excluir();
		Listar();
	});

	$("#tblListar").on("click", ".btnDone", function(){
		indice_selecionado = parseInt($(this).attr("alt"));
		//Aba caso queira colocar sistema de pontuação
		Concluido();
		Listar();
	});

});