var btn = document.getElementById('btn');
btn.addEventListener('click', function () {
    alert('Mensagem enviada');
})